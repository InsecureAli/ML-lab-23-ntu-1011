# Author: Ali Hassan
# Roll No.: 23-NTU-CS-1011

### ==========================================
### PHASE 1: INITIALIZATION
### ==========================================
import pandas as pd
import matplotlib.pyplot as plt

### ==========================================
### PHASE 2: DATA ACQUISITION
### ==========================================
# Extracting records from various file extensions
df_students = pd.read_csv("students.csv")
print(">>> Student Directory:")
print(df_students)

df_presence = pd.read_json("attendance.json")
print("\n>>> Attendance Logs:")
print(df_presence)

df_bonus = pd.read_excel("extra.xlsx")
print("\n>>> Bonus Credits:")
print(df_bonus)


### ==========================================
### PHASE 3: DATA INTEGRATION
### ==========================================
# Using method chaining to seamlessly merge all three DataFrames on 'Name'
merged_df = (
    df_students
    .merge(df_presence, on="Name", how="inner")
    .merge(df_bonus, on="Name", how="inner")
)

print("\n>>> Unified Dataset:")
print(merged_df)


### ==========================================
### PHASE 4: FEATURE SELECTION
### ==========================================
# Isolating only the variables required for the current analysis
target_features = ["Name", "Marks", "Attendance", "Bonus"]
analysis_df = merged_df.loc[:, target_features].copy()

print("\n>>> Filtered Features:")
print(analysis_df)


### ==========================================
### PHASE 5: CORRELATION VISUALIZATION
### ==========================================
# Masking the dataset based on the 70% attendance threshold
optimal_attendance = analysis_df[analysis_df["Attendance"] >= 70]
critical_attendance = analysis_df[analysis_df["Attendance"] < 70]

plt.figure(figsize=(8, 5))

# Plotting the optimal attendance group
plt.scatter(
    optimal_attendance["Marks"], 
    optimal_attendance["Attendance"], 
    color="mediumseagreen", 
    s=70, 
    edgecolors="black",
    label="Pass (≥ 70%)"
)

# Plotting the critical attendance group with a different marker
plt.scatter(
    critical_attendance["Marks"], 
    critical_attendance["Attendance"], 
    color="tomato", 
    marker="X",
    s=70, 
    label="Critical (< 70%)"
)

# Plot aesthetics and labeling
plt.axhline(y=70, color='gray', linestyle='--', alpha=0.5) # Visual threshold line
plt.xlabel("Acquired Marks")
plt.ylabel("Attendance Percentage (%)")
plt.title("Academic Performance vs. Class Attendance")
plt.legend(frameon=True, shadow=True)
plt.grid(True, linestyle=":", alpha=0.6)

plt.tight_layout()
plt.show()


### ==========================================
### PHASE 6: CATEGORICAL TRANSFORMATION
### ==========================================
# Converting the nominal 'Name' feature into binary vectors via One-Hot Encoding
# Adding dtype=int converts the True/False output to cleaner 1s and 0s
final_encoded_df = pd.get_dummies(analysis_df, columns=["Name"], dtype=int)

print("\n>>> Dataset Post One-Hot Encoding:")
print(final_encoded_df)