# Name: Ali Hassan
# Roll Number: 23-NTU-CS-1011

# =========================================================
# MODULE 1: DEPENDENCIES
# =========================================================
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.preprocessing import LabelEncoder

# =========================================================
# MODULE 2: SYNTHETIC DATA GENERATION
# =========================================================
np.random.seed(10) # Keeping the same seed for consistent random data

# Generating arrays for student demographics and scores
stu_ids = np.arange(1, 101)
math_scores = np.random.randint(40, 101, size=100)
sci_scores = np.random.randint(40, 101, size=100)
eng_scores = np.random.randint(40, 101, size=100)
assigned_grades = np.random.choice(["A", "B", "C"], size=100)

# =========================================================
# MODULE 3: DATAFRAME CONSTRUCTION
# =========================================================
records_df = pd.DataFrame({
    "Student_ID": stu_ids,
    "Math_Score": math_scores,
    "Science_Score": sci_scores,
    "English_Score": eng_scores,
    "Category": assigned_grades
})

print("--- Initial 10 Records ---")
print(records_df.head(10))

# =========================================================
# MODULE 4: NULL VALUE INJECTION
# =========================================================
# Using list passing to batch-assign NaN values efficiently
records_df.loc[[5, 15, 25], "Math_Score"] = np.nan
records_df.loc[[10, 20], "Science_Score"] = np.nan
records_df.loc[[30, 40], "English_Score"] = np.nan

print("\n--- Missing Value Count ---")
print(records_df.isna().sum())

# =========================================================
# MODULE 5: MEAN IMPUTATION
# =========================================================
# Iterating through columns instead of processing them one by one
for subject in ["Math_Score", "Science_Score", "English_Score"]:
    mean_val = records_df[subject].mean()
    records_df[subject] = records_df[subject].fillna(mean_val)

print("\n--- Post-Imputation Records ---")
print(records_df.head(10))

# =========================================================
# MODULE 6: CATEGORICAL ENCODING
# =========================================================
category_encoder = LabelEncoder()
records_df["Category_Num"] = category_encoder.fit_transform(records_df["Category"])

print("\n--- Encoded Categories ---")
print(records_df[["Category", "Category_Num"]].head(10))

# =========================================================
# MODULE 7: AGGREGATE SCORING
# =========================================================
# Using vector summation across the row axis instead of a+b+c
subject_cols = ["Math_Score", "Science_Score", "English_Score"]
records_df["Aggregate_Score"] = records_df[subject_cols].sum(axis=1)

print("\n--- Aggregated Results ---")
print(records_df[["Student_ID", "Math_Score", "Science_Score", "English_Score", "Aggregate_Score"]].head(10))

# =========================================================
# MODULE 8: HISTOGRAM VISUALIZATION (MATH)
# =========================================================
plt.figure(figsize=(7, 4))
plt.hist(records_df["Math_Score"], bins=10, color='coral', edgecolor='black', alpha=0.8)
plt.title("Distribution of Math Scores")
plt.xlabel("Scores")
plt.ylabel("Frequency")
plt.grid(axis='y', linestyle='--', alpha=0.5)
plt.show()

# =========================================================
# MODULE 9: BOXPLOT VISUALIZATION (TOTALS)
# =========================================================
plt.figure(figsize=(5, 6))
plt.boxplot(records_df["Aggregate_Score"], patch_artist=True, boxprops=dict(facecolor='lightblue', color='blue'))
plt.title("Aggregate Scores Distribution")
plt.ylabel("Total Marks")
plt.show()

# =========================================================
# MODULE 10: OUTLIER DETECTION (IQR METHOD)
# =========================================================
q25 = records_df["Aggregate_Score"].quantile(0.25)
q75 = records_df["Aggregate_Score"].quantile(0.75)
iqr_val = q75 - q25

floor_limit = q25 - (1.5 * iqr_val)
ceiling_limit = q75 + (1.5 * iqr_val)

score_anomalies = records_df[
    (records_df["Aggregate_Score"] < floor_limit) | 
    (records_df["Aggregate_Score"] > ceiling_limit)
]

print("\n--- Detected Score Anomalies ---")
print(score_anomalies[["Student_ID", "Category", "Aggregate_Score"]])

# =========================================================
# MODULE 11: PERFORMANCE ANALYSIS BY CATEGORY
# =========================================================
category_means = records_df.groupby("Category")["Aggregate_Score"].mean()

print("\n--- Average Aggregate by Category ---")
print(category_means)

top_performing_cat = category_means.idxmax()
top_avg_score = category_means.max()

print(f"\nTop Performing Category: {top_performing_cat}")
print(f"Highest Average Score: {top_avg_score:.2f}")