# Author: Ali Hassan
# Roll No.: 23-NTU-CS-1011

# ==========================================
# STAGE 1: ENVIRONMENT SETUP
# ==========================================
import pandas as pd
import matplotlib.pyplot as plt

# ==========================================
# STAGE 2: DATA INGESTION
# ==========================================
csv_link = "https://raw.githubusercontent.com/datasets/covid-19/master/data/time-series-19-covid-combined.csv"
global_covid_df = pd.read_csv(csv_link)

print("--- Global Dataset Snapshot ---")
print(global_covid_df.head())

# ==========================================
# STAGE 3: FILTERING TARGET REGION
# ==========================================
# Safely isolating the data for Pakistan using loc
pk_covid_data = global_covid_df.loc[global_covid_df["Country/Region"] == "Pakistan"].copy()

print("\n--- Pakistan Dataset Snapshot ---")
print(pk_covid_data.head())

# ==========================================
# STAGE 4: NULL VALUE INSPECTION
# ==========================================
print("\n--- Pre-Cleaning Null Counts ---")
print(pk_covid_data.isna().sum())

# ==========================================
# STAGE 5: DATA SANITIZATION
# ==========================================
# Applying fillna using a mapped dictionary for cleaner, one-step execution
fill_targets = {"Confirmed": 0, "Recovered": 0, "Deaths": 0}
pk_covid_data.fillna(value=fill_targets, inplace=True)

print("\n--- Post-Cleaning Null Counts ---")
print(pk_covid_data.isna().sum())

# ==========================================
# STAGE 6: DATETIME PARSING
# ==========================================
pk_covid_data["Date"] = pd.to_datetime(pk_covid_data["Date"])

# ==========================================
# STAGE 7: DAILY METRICS CALCULATION
# ==========================================
# Utilizing diff() for day-over-day changes and chaining fillna for the first index
pk_covid_data["Incident_Cases"] = pk_covid_data["Confirmed"].diff().fillna(0)

print("\n--- Daily Incident Metrics ---")
print(pk_covid_data[["Date", "Confirmed", "Incident_Cases"]].head())

# ==========================================
# STAGE 8: TIME-SERIES VISUALIZATION
# ==========================================
plt.figure(figsize=(9, 5))
plt.plot(pk_covid_data["Date"], pk_covid_data["Confirmed"], color="crimson", linewidth=2)

plt.title("Cumulative COVID-19 Trajectory in Pakistan", fontsize=13, pad=10)
plt.xlabel("Timeline")
plt.ylabel("Total Confirmed Cases")
plt.grid(True, linestyle="--", linewidth=0.5, alpha=0.7)
plt.xticks(rotation=30)
plt.tight_layout()

plt.show()

# ==========================================
# STAGE 9: PEAK CONFIRMED CASES IDENTIFICATION
# ==========================================
# Using nlargest to cleanly extract the row with the maximum cases
peak_record = pk_covid_data.nlargest(1, "Confirmed").iloc[0]

print("\n--- Peak Cumulative Record ---")
print(f"Date Recorded: {peak_record['Date'].date()}")
print(f"Total Cases: {int(peak_record['Confirmed'])}")

# ==========================================
# STAGE 10: SPREAD DISTRIBUTION (BOXPLOT)
# ==========================================
plt.figure(figsize=(6, 7))
# Adding some visual styling to the boxplot
plt.boxplot(pk_covid_data["Incident_Cases"], patch_artist=True, boxprops=dict(facecolor="lightcoral"))

plt.title("Distribution of Daily Incident Cases")
plt.ylabel("New Cases Per Day")
plt.show()

# ==========================================
# STAGE 11: STATISTICAL ANOMALY DETECTION
# ==========================================
p25 = pk_covid_data["Incident_Cases"].quantile(0.25)
p75 = pk_covid_data["Incident_Cases"].quantile(0.75)
iq_range = p75 - p25

# Defining outlier thresholds
bottom_fence = p25 - (1.5 * iq_range)
top_fence = p75 + (1.5 * iq_range)

# Extracting anomalous records
anomaly_df = pk_covid_data[
    (pk_covid_data["Incident_Cases"] < bottom_fence) | 
    (pk_covid_data["Incident_Cases"] > top_fence)
]

print("\n--- Detected Anomalies (Incident Cases) ---")
print(anomaly_df[["Date", "Incident_Cases"]])