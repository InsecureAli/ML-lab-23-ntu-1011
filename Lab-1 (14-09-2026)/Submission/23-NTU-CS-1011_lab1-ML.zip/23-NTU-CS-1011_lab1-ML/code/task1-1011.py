#  -- ------------------------------TASK 1--------------------------------- -

#  Name: Ali Hassan
# Roll Number: 23-NTU-CS- 1011

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.preprocessing import LabelEncoder

# ==========================================
# PHASE 1: DATA INITIALIZATION
# ==========================================

# Structuring the provincial data into a DataFrame directly
provincial_data = pd.DataFrame({
    "Province": ["Punjab", "Sindh", "KPK", "Balochistan"],
    "Population": [127.69, 55.70, 40.86, 14.89], # in millions
    "Literacy": [66.25, 57.54, 51.09, 42.01],    # in percentage
    "Region": ["East", "South", "North", "West"]
})

print("--- Initial DataFrame ---")
print(provincial_data)


# ==========================================
# PHASE 2: INJECTING NULL VALUES
# ==========================================

# Using numpy's nan to simulate missing data
provincial_data.loc[1, "Literacy"] = np.nan
provincial_data.loc[2, "Population"] = np.nan

print("\n--- DataFrame with Missing Data ---")
print(provincial_data)


# ==========================================
# PHASE 3: IMPUTATION (MEDIAN)
# ==========================================

# Calculate the median and fill the missing Literacy value
literacy_median = provincial_data["Literacy"].median()
provincial_data["Literacy"] = provincial_data["Literacy"].fillna(literacy_median)

print("\n--- Post-Imputation (Literacy) ---")
print(provincial_data)


# ==========================================
# PHASE 4: DATA CLEANING (DROPPING)
# ==========================================

# Drop any remaining rows with NaN values (KPK's population)
clean_df = provincial_data.dropna().copy()

print("\n--- Cleaned DataFrame ---")
print(clean_df)


# ==========================================
# PHASE 5: LABEL ENCODING
# ==========================================

encoder = LabelEncoder()

# Generating a numerical representation of the Region
clean_df["Region_Encoded"] = encoder.fit_transform(clean_df["Region"])

print("\n--- Post Label Encoding ---")
print(clean_df)


# ==========================================
# PHASE 6: ONE-HOT ENCODING
# ==========================================

# Transforming the categorical Region column into dummy variables
final_df = pd.get_dummies(clean_df, columns=["Region"])

print("\n--- Post One-Hot Encoding ---")
print(final_df)


# ==========================================
# PHASE 7: VISUALIZATION
# ==========================================

plt.figure(figsize=(8, 5))

# Generating the scatter plot
plt.scatter(final_df["Population"], final_df["Literacy"], color='teal', marker='D')

# Annotating the graph using iterrows() instead of range/len
for index, row in final_df.iterrows():
    plt.annotate(
        row["Province"], 
        (row["Population"], row["Literacy"]), 
        textcoords="offset points", 
        xytext=(8, -3), 
        ha='left'
    )

# Formatting labels and title
plt.xlabel("Total Population (Millions)")
plt.ylabel("Literacy Rate (%)")
plt.title("Provincial Demographics: Population vs. Literacy")
plt.grid(True, linestyle='--', alpha=0.5)

plt.show()


# ==========================================
# PHASE 8: OUTLIER DETECTION (IQR)
# ==========================================

# Establishing quartiles and Interquartile Range (IQR)
q1_val = final_df["Literacy"].quantile(0.25)
q3_val = final_df["Literacy"].quantile(0.75)
iqr_val = q3_val - q1_val

# Defining the boundaries for normal data points
lower_bound = q1_val - (1.5 * iqr_val)
upper_bound = q3_val + (1.5 * iqr_val)

# Extracting any data points that fall outside the bounds
outliers_df = final_df[
    (final_df["Literacy"] < lower_bound) | 
    (final_df["Literacy"] > upper_bound)
]

print("\n--- Detected Outliers (Literacy Rate) ---")
print(outliers_df[["Province", "Literacy"]])