# Author: Ali Hassan
# Roll No.: 23-NTU-CS-1011

# <><><><><><><><><><><><><><><><><><><><><><><>
# SECTION 1: LIBRARY IMPORTS
# <><><><><><><><><><><><><><><><><><><><><><><>
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import LabelEncoder

# <><><><><><><><><><><><><><><><><><><><><><><>
# SECTION 2: DATA STRUCTURE INITIALIZATION
# <><><><><><><><><><><><><><><><><><><><><><><>
employee_records = {
    "Name": ["Ahsan", "Hira", "Bilal", "Zara", "Salman", "Mahnoor"],
    "Age": [25, 27, 35, 29, None, 40],
    "Salary": [50000, None, 75000, 2000000, 60000, 90000],
    "Department": ["IT", "Finance", "IT", "HR", "Finance", "IT"]
}

hr_dataframe = pd.DataFrame(employee_records)

print("=== Raw Employee Records ===")
print(hr_dataframe)

# <><><><><><><><><><><><><><><><><><><><><><><>
# SECTION 3: MISSING DATA EVALUATION
# <><><><><><><><><><><><><><><><><><><><><><><>
print("\n=== Null Value Assessment ===")
print(hr_dataframe.isna().sum())

# <><><><><><><><><><><><><><><><><><><><><><><>
# SECTION 4: AUTOMATED MEAN IMPUTATION
# <><><><><><><><><><><><><><><><><><><><><><><>
# Consolidating imputation targets into a single mapping dictionary
imputation_map = {
    "Age": hr_dataframe["Age"].mean(),
    "Salary": hr_dataframe["Salary"].mean()
}
hr_dataframe.fillna(value=imputation_map, inplace=True)

print("\n=== Records Post-Imputation ===")
print(hr_dataframe)

# <><><><><><><><><><><><><><><><><><><><><><><>
# SECTION 5: CATEGORICAL ENCODING
# <><><><><><><><><><><><><><><><><><><><><><><>
dept_encoder = LabelEncoder()
hr_dataframe["Dept_Code"] = dept_encoder.fit_transform(hr_dataframe["Department"])

print("\n=== Records with Encoded Departments ===")
print(hr_dataframe)

# <><><><><><><><><><><><><><><><><><><><><><><>
# SECTION 6: SALARY OUTLIER VISUALIZATION
# <><><><><><><><><><><><><><><><><><><><><><><>
fig, ax = plt.subplots(figsize=(7, 3))
# Displaying the boxplot horizontally with custom styling
ax.boxplot(hr_dataframe["Salary"], vert=False, patch_artist=True, boxprops=dict(facecolor="gold"))

ax.set_xlabel("Compensation Value (PKR)")
ax.set_title("Distribution and Anomaly Detection in Salaries")
plt.tight_layout()
plt.show()

# <><><><><><><><><><><><><><><><><><><><><><><>
# SECTION 7: STATISTICAL OUTLIER EXTRACTION
# <><><><><><><><><><><><><><><><><><><><><><><>
p25 = hr_dataframe["Salary"].quantile(0.25)
p75 = hr_dataframe["Salary"].quantile(0.75)
iqr_spread = p75 - p25

floor_bound = p25 - (1.5 * iqr_spread)
ceiling_bound = p75 + (1.5 * iqr_spread)

# Using pandas query syntax for a cleaner filtration process
anomalous_salaries = hr_dataframe.query("Salary < @floor_bound or Salary > @ceiling_bound")

print("\n=== Detected Salary Anomalies ===")
print(anomalous_salaries)

# <><><><><><><><><><><><><><><><><><><><><><><>
# SECTION 8: INDIVIDUAL RECORD ANALYSIS (ZARA)
# <><><><><><><><><><><><><><><><><><><><><><><>
# Extracting Zara's specific salary value directly as a float
zara_compensation = hr_dataframe.loc[hr_dataframe["Name"] == "Zara", "Salary"].values[0]

print(f"\nTarget Lookup - Zara's Compensation: {zara_compensation}")

if not (floor_bound <= zara_compensation <= ceiling_bound):
    print("Evaluation: Zara's compensation is classified as a statistical anomaly.")
else:
    print("Evaluation: Zara's compensation falls within standard deviation ranges.")