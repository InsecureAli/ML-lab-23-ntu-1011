# Name: Ali Hassan
# Roll Number: 23-NTU-CS-1011

# ========================================================
# MODULE A: DEPENDENCIES & SETUP
# ========================================================
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.datasets import load_breast_cancer
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.model_selection import train_test_split
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score

# ========================================================
# MODULE B: DATA INGESTION & STRUCTURING
# ========================================================
cancer_data = load_breast_cancer()

# Constructing the main DataFrame
features_df = pd.DataFrame(cancer_data.data, columns=cancer_data.feature_names)
features_df["target_class"] = cancer_data.target

print(f"--- Dataset Overview ---")
print(f"Available Keys: {list(cancer_data.keys())}")
print(f"Target Categories: {cancer_data.target_names}")
print(f"Total Records: {cancer_data.data.shape[0]}")
print(f"Total Features: {cancer_data.data.shape[1]}")
print(f"Feature Dimensions: {cancer_data.data.shape}")
print(f"Target Dimensions: {cancer_data.target.shape}")

# ========================================================
# MODULE C: NULL VALUE INJECTION & IMPUTATION
# ========================================================
initial_nulls = features_df.isna().sum().sum()
print(f"\nBaseline Null Values: {initial_nulls}")

# Injecting artificial NaNs (using pandas sample for cleaner random indexing)
np.random.seed(10)
random_indices = features_df.sample(n=5, random_state=10).index
features_df.loc[random_indices, "mean radius"] = np.nan

print(f"Nulls in 'mean radius' post-injection: {features_df['mean radius'].isna().sum()}")

# Imputing with median to resist outlier influence
radius_median = features_df["mean radius"].median()
features_df["mean radius"] = features_df["mean radius"].fillna(radius_median)

print(f"Nulls post-imputation: {features_df['mean radius'].isna().sum()}")
print("-> Imputation Strategy: Median (Outlier-resistant)")

# ========================================================
# MODULE D: CLASS DISTRIBUTION & WEIGHTING
# ========================================================
print("\n--- Target Distribution Analysis ---")
dist_counts = features_df["target_class"].value_counts()
dist_props = features_df["target_class"].value_counts(normalize=True) * 100

print(f"Raw Counts:\n{dist_counts}")
print(f"Percentages:\n{dist_props.round(2)}")
print(f"Legend: {dict(enumerate(cancer_data.target_names))}")

class_discrepancy = abs(dist_counts[0] - dist_counts[1])
print(f"\nAbsolute Difference Between Classes: {class_discrepancy}")

if class_discrepancy > 50:
    print("-> Status: The dataset exhibits class imbalance.")
else:
    print("-> Status: The dataset is reasonably balanced.")

print("-> Resolution: Algorithmic weighting (class_weight='balanced') will be applied natively in the SVM.")

# ========================================================
# MODULE E: OUTLIER ANALYSIS (VISUAL & IQR)
# ========================================================
fig, ax = plt.subplots(figsize=(8, 4))
ax.boxplot(
    [features_df["mean radius"], features_df["mean texture"]],
    labels=["Radius (Mean)", "Texture (Mean)"],
    patch_artist=True, boxprops=dict(facecolor="lightblue")
)
ax.set_title("Distribution & Outliers: Radius vs Texture")
plt.show()

def extract_anomalies(series_data):
    """Calculates and filters statistical anomalies based on IQR"""
    q25, q75 = series_data.quantile([0.25, 0.75])
    iqr_spread = q75 - q25
    floor = q25 - (1.5 * iqr_spread)
    ceiling = q75 + (1.5 * iqr_spread)
    return series_data[(series_data < floor) | (series_data > ceiling)]

radius_anomalies = extract_anomalies(features_df["mean radius"])
texture_anomalies = extract_anomalies(features_df["mean texture"])

print(f"\nDetected Anomalies (Mean Radius): {len(radius_anomalies)} instances")
print(radius_anomalies)
print(f"\nDetected Anomalies (Mean Texture): {len(texture_anomalies)} instances")
print(texture_anomalies)

# ========================================================
# MODULE F: FEATURE ENGINEERING (LOG TRANSFORM)
# ========================================================
# Using mathematical log equivalent to log1p (log(1 + x))
features_df["log_transformed_area"] = np.log(features_df["mean area"] + 1)

# Visualizing the transformation side-by-side using subplots for a cleaner look
fig, axes = plt.subplots(1, 2, figsize=(12, 4))

axes[0].hist(features_df["mean area"], bins=30, color='coral', edgecolor='black')
axes[0].set_title("Pre-Transformation (Mean Area)")

axes[1].hist(features_df["log_transformed_area"], bins=30, color='teal', edgecolor='black')
axes[1].set_title("Post-Transformation (Log Mean Area)")

plt.tight_layout()
plt.show()

# ========================================================
# MODULE G: PREPROCESSING & DIMENSIONALITY REDUCTION
# ========================================================
# Isolating features and targets
X_features = features_df.drop(columns=["target_class", "log_transformed_area"])
y_labels = features_df["target_class"]

# Standardizing
std_scaler = StandardScaler()
X_scaled = std_scaler.fit_transform(X_features)

print(f"\nProcessed Feature Matrix Dimensions: {X_scaled.shape}")

# Reducing to 2 Principal Components
pca_engine = PCA(n_components=2)
X_reduced = pca_engine.fit_transform(X_scaled)

print(f"PCA Reduced Matrix Dimensions: {X_reduced.shape}")
print(f"Variance Retained per Component: {pca_engine.explained_variance_ratio_}")

# PCA Scatter Plot
fig, ax = plt.subplots(figsize=(8, 5))
scatter = ax.scatter(X_reduced[:, 0], X_reduced[:, 1], c=y_labels, cmap='coolwarm', alpha=0.7)

# Creating a legend mapping the colors to class names
legend_handles = scatter.legend_elements()[0]
ax.legend(legend_handles, ["Malignant (0)", "Benign (1)"], title="Diagnosis")

ax.set_xlabel("Principal Component I")
ax.set_ylabel("Principal Component II")
ax.set_title("2D PCA Projection of Breast Cancer Features")
plt.show()

# ========================================================
# MODULE H: MODEL TRAINING & EVALUATION
# ========================================================
X_tr, X_te, y_tr, y_te = train_test_split(
    X_scaled, y_labels, test_size=0.2, random_state=42, stratify=y_labels
)

# 1. Support Vector Classifier
svc_classifier = SVC(class_weight="balanced", random_state=42)
svc_classifier.fit(X_tr, y_tr)
svc_preds = svc_classifier.predict(X_te)
svc_acc = accuracy_score(y_te, svc_preds)

# 2. K-Nearest Neighbors Classifier
knn_classifier = KNeighborsClassifier(n_neighbors=5)
knn_classifier.fit(X_tr, y_tr)
knn_preds = knn_classifier.predict(X_te)
knn_acc = accuracy_score(y_te, knn_preds)

print("\n" + "="*35)
print("     ALGORITHM ACCURACY REPORT")
print("="*35)
print(f"SVC Accuracy (Balanced):  {svc_acc:.4f}")
print(f"KNN Accuracy (k=5):       {knn_acc:.4f}")
print("="*35)